﻿using readifyTest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace readifyTest.Controllers
{
    public class TokenController : ApiController
    {
        readonly Token token = new Token { TokenKey = "94a92218-e37b-457a-8ef1-e9bd97b57586" };

        public IHttpActionResult GetToken()
        {
            return Ok(token.TokenKey);
        }
    }
}
