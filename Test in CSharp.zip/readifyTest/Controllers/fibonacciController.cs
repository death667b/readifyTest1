﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace readifyTest.Controllers
{
    public class fibonacciController : ApiController
    {
        public IHttpActionResult GetFibonacci(string n)
        {
            Int64 intN, fibValue;

            // Catch any value that is not a integer and return 'no content'
            try
            {
                intN = Int64.Parse(n);
            }
            catch (FormatException e)
            {
                return Content(HttpStatusCode.BadRequest, "no content");
            }

            // Only accept numbers below 93 - it exceeds that value range of a 64bit integer
            if (intN >= 93)
            {
                return Content(HttpStatusCode.BadRequest, "no content");
            }

            fibValue = CalcFibonacci(intN);

            return Ok(fibValue);
        }

        private Int64 CalcFibonacci(Int64 n)
        {
            Int64 numberToCalc = n + 1;
            Int64[] arr = new Int64[numberToCalc];

            // Seed array
            arr[0] = 0;
            arr[1] = 1;

            for (Int64 i = 2; i < numberToCalc; i++)
            {
                arr[i] = arr[i - 2] + arr[i - 1];
            }

            return arr[n];
        }
    }
}
