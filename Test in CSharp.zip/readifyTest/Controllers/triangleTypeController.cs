﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace readifyTest.Controllers
{
    public class triangleTypeController : ApiController
    {
        public IHttpActionResult GetTriangleType(string a, string b, string c)
        {
            int intA, intB, intC;
            
            // Test user input for correct values, this is to stop the web server from falling over
            try
            {
                intA = Int32.Parse(a);
                intB = Int32.Parse(b);
                intC = Int32.Parse(c);
            }
            catch (FormatException e)
            {
                return Ok("Error");
            }

            // All values must be greater than zero
            if (intA <= 0 || intB <= 0 || intC <= 0)
            {
                return Ok("Error");
            }

            // Test for the triangle inequality theorem
            if (intA + intB <= intC || intA + intC <= intB || intB + intC <= intA)
            {
                return Ok("Error");
            }

            // Test for Equilateral triangle - All sides are equal
            if (intA == intB && intB == intC)
            {
                return Ok("Equilateral");
            }

            // Test for Isosceles triangle - Any two sides must be equal
            if (intA == intB || intA == intC || intB == intC)
            {
                return Ok("Isosceles");
            }

            // Test for Scalene triangle - All sides are different lengths
            if (intA != intB && intA != intB && intB != intC)
            {
                return Ok("Scalene");
            }

            // A catchall error - this should never get touched
            return Ok("Error");
        }
    }
}
