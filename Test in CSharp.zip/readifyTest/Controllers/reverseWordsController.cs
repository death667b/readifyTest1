﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace readifyTest.Controllers
{
    public class ReverseWordsController : ApiController
    {
        public IHttpActionResult GetReverseWords(string sentence)
        {
            string returnSentece = "";

            if (sentence == null)
            {
                return NotFound();
            }

            string[] splitSentence = sentence.Split(new Char[] { ' ', ',', '.', ':', '\t' });

            foreach(string word in splitSentence)
            {
                Char[] wordChar = word.ToCharArray();
                Array.Reverse(wordChar);

                returnSentece += string.Join("", wordChar) + " ";
            }
            
            return Ok(returnSentece.Trim());
        }
    }
}
